# ChatData Insight

## 运行项目

```shell
npm install

npm run dev
```
