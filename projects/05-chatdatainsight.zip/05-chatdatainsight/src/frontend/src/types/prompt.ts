export interface Prompt {
  id: string;
  name: string;
  prompt: string;
}
