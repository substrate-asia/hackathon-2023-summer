# Amphi
Amphi for translator 

# nginx install
pnpm install


# How to run project
npm run  dev
