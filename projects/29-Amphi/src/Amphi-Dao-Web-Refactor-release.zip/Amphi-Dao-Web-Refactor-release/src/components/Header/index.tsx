import React from 'react';
import { Layout } from 'antd';
import logo from '@/assets/svg/logo.svg';
import MainMenu from '../MainMenu';
import ConnectWallet from '../ConnectWallet';
import styles from './index.module.scss';

const { Header } = Layout;

const AmHeader = () => {
    return (
        <Header className={styles['amphi-header']}>
            <a href='/' className={styles.logo}>
                <img src={logo} alt='' />
            </a>
            <MainMenu />
            <ConnectWallet />
        </Header>
    );
};

export default AmHeader;
