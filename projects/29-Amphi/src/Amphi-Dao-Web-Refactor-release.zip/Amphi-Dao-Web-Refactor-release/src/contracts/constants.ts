export const DefaultPrecision = 18;
export const Token = 'USDT';
