import common from './common.json';
import moduleA from './moduleA.json';

export default { common, moduleA };
